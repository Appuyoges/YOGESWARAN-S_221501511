# ARCORE MEASUREMENT

<a href="https://www.buymeacoffee.com/kashifmehmood"><img src="https://img.buymeacoffee.com/button-api/?text=Buy me a coffee&emoji=&slug=kashifmehmood&button_colour=FFDD00&font_colour=000000&font_family=Cookie&outline_colour=000000&coffee_colour=ffffff" /></a>

This app is build using sceneform sdk for android using kotlin language
It helps you measure the distance between multiple points in your space
After measuring the distance it also generates a 3d view of you measurement


## Installation

Clone the repo and open it in android studio



## Usage

after installing you  can start using and start measuring


## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
[MIT](https://choosealicense.com/licenses/mit/)
